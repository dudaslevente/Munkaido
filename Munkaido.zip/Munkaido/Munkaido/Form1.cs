﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Munkaido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public class TMunkaido
        {
            public string Alkalmazott;
            public DateTime Datum;
            public string Kezdet;
            public string Veg;

            public TMunkaido(string row)
            {
                string[] seged = row.Split(';');
                this.Alkalmazott = seged[0];
                this.Datum = Convert.ToDateTime(seged[1]);
                this.Kezdet = seged[2];
                this.Veg = seged[3];
            }
        }

        public class TEloleg
        {
            public string Alkalmazott;
            public DateTime Datum;
            public int Eloleg;

            public TEloleg(string row)
            {
                string[] seged = row.Split(';');
                this.Alkalmazott = seged[0];
                this.Datum = Convert.ToDateTime(seged[1]);
                this.Eloleg = Convert.ToInt32(seged[2]);
            }
        }

        static List<TMunkaido> munkaido = new List<TMunkaido>();
        static List<TEloleg> eloleg = new List<TEloleg>();
        public static bool isLoaded = false;
        public static bool isChanged = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadFromFileMunkaido();
            LoadFromFileEloleg();
        }

        private void LoadFromFileMunkaido()
        {
            try
            {
                StreamReader file = new StreamReader("munkaido.txt", Encoding.UTF8);
                file.ReadLine();
                while (!file.EndOfStream)
                {
                    munkaido.Add(new TMunkaido(file.ReadLine()));
                }
                file.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Hiba az adatok beolvasásában!" + ex.Message);
            }
        }

        private void LoadFromFileEloleg()
        {
            try
            {
                StreamReader file = new StreamReader("eloleg.txt", Encoding.UTF8);
                file.ReadLine();
                while (!file.EndOfStream)
                {
                    eloleg.Add(new TEloleg(file.ReadLine()));
                }
                file.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Hiba az adatok beolvasásában!" + ex.Message);
            }
        }
    }
}
