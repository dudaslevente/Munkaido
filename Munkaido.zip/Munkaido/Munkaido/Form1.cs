﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Munkaido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public class TMunkaido
        {
            public string Alkalmazott;
            public string Datum;
            public string Kezdet;
            public string Veg;

            public TMunkaido(string row)
            {
                string[] seged = row.Split(';');
                this.Alkalmazott = seged[0];
                this.Datum = seged[1];
                this.Kezdet = seged[2];
                this.Veg = seged[3];
            }
        }

        public class TEloleg
        {
            public string Alkalmazott;
            public string Datum;
            public int Eloleg;

            public TEloleg(string row)
            {
                string[] seged = row.Split(';');
                this.Alkalmazott = seged[0];
                this.Datum = seged[1];
                this.Eloleg = Convert.ToInt32(seged[2]);
            }
        }

        public class TMunkavallalo
        {
            public string Nev;
            public string Lakcim;
            public string Beosztas;
            public int Oraber;
            public string Telefonszam;
            public string Email;

            public TMunkavallalo(string row)
            {
                string[] seged = row.Split(';');
                this.Nev = seged[0];
                this.Lakcim = seged[1];
                this.Beosztas = seged[2];
                this.Oraber = Convert.ToInt32(seged[3]);
                this.Telefonszam = seged[4];
                this.Email = seged[5];
            }
        }

        static List<TMunkavallalo> munkavallalok = new List<TMunkavallalo>();
        static List<TMunkaido> munkaido = new List<TMunkaido>();
        static List<TEloleg> eloleg = new List<TEloleg>();
        public static bool isLoaded = false;
        public static bool isChanged = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadFromFileMunkaido();
            LoadFromFileEloleg();
            LoadFromFileMunkavallalo();
            UpdateGrid();
            munkavallalok.ForEach(item =>
            {
                comboBox1.Items.Add(item.Nev);
                comboBox2.Items.Add(item.Nev);
            });
            munkaido.ForEach(item =>
            {
                comboBox3.Items.Add(item.Datum);
            });
        }

        private void LoadFromFileMunkaido()
        {
            try
            {
                StreamReader file = new StreamReader("munkaidok.txt", Encoding.UTF8);
                file.ReadLine();
                while (!file.EndOfStream)
                {
                    munkaido.Add(new TMunkaido(file.ReadLine()));
                }
                file.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Hiba az adatok beolvasásában!" + ex.Message);
            }
        }

        private void LoadFromFileEloleg()
        {
            try
            {
                StreamReader file = new StreamReader("elolegek.txt", Encoding.UTF8);
                file.ReadLine();
                while (!file.EndOfStream)
                {
                    eloleg.Add(new TEloleg(file.ReadLine()));
                }
                file.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Hiba az adatok beolvasásában!" + ex.Message);
            }
        }

        private void LoadFromFileMunkavallalo()
        {
            try
            {
                StreamReader file = new StreamReader("munkavalallok.txt", Encoding.UTF8);
                file.ReadLine();
                while (!file.EndOfStream)
                {
                    munkavallalok.Add(new TMunkavallalo(file.ReadLine()));
                }
                file.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Hiba az adatok beolvasásában!" + ex.Message);
            }
        }

        private void UpdateGrid()
        {
            munkaidoGrid.Rows.Clear();
            munkaido.ForEach(item =>
            {
                munkaidoGrid.Rows.Add();
                munkaidoGrid.Rows[munkaidoGrid.Rows.Count - 1].Cells[0].Value = item.Alkalmazott;
                munkaidoGrid.Rows[munkaidoGrid.Rows.Count - 1].Cells[1].Value = item.Datum;
                munkaidoGrid.Rows[munkaidoGrid.Rows.Count - 1].Cells[2].Value = item.Kezdet;
                munkaidoGrid.Rows[munkaidoGrid.Rows.Count - 1].Cells[3].Value = item.Veg;
            });

            elolegGrid.Rows.Clear();
            eloleg.ForEach(item =>
            {
                elolegGrid.Rows.Add();
                elolegGrid.Rows[elolegGrid.Rows.Count - 1].Cells[0].Value = item.Alkalmazott;
                elolegGrid.Rows[elolegGrid.Rows.Count - 1].Cells[1].Value = item.Datum;
                elolegGrid.Rows[elolegGrid.Rows.Count - 1].Cells[2].Value = item.Eloleg;
            });

            munkavallaloGrid.Rows.Clear();
            munkavallalok.ForEach(item =>
            {
                munkavallaloGrid.Rows.Add();
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[0].Value = item.Nev;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[1].Value = item.Lakcim;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[2].Value = item.Beosztas;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[3].Value = item.Oraber;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[4].Value = item.Telefonszam;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[5].Value = item.Email;
            });

            SetDefaultStateMunkavallalo();
            SetDefaultStateMunkaido();
            SetDefaultStateEloleg();
            UpdateStatistics();
            isLoaded = true;
        }

        private void UpdateStatistics()
        {
            //JÓ
            munkavallalok.ForEach(item =>
            {
                if (item.Nev == textBox1.Text.Split(' ')[0])
                {
                    textBox9.Text = item.Nev.ToString();
                }
            });
            munkaido.ForEach(item =>
            {
                if (item.Datum == comboBox3.Text.Split(' ')[0])
                {
                    string honap = item.Datum.Split('.')[1];
                    textBox13.Text = honap.ToString();
                }
            });

            //ROSSZ

            OraKivonas();

            /*
            eloleg.ForEach(item =>
            {
                if (item.Eloleg == Convert.ToInt32(textBox7.Text.Split(' ')[0]))
                {
                    textBox16.Text = item.Eloleg.ToString();
                }
            });
            */
        }

        private void OraKivonas()
        {
            munkaido.ForEach(item =>
            {
                string osszKezdOra = "";
                string osszVegOra = "";
                int kulonbseg = 0;
                int osszOra = 0;

                string kezdOra = item.Kezdet.Split(':')[0];
                string kezdPerc = item.Kezdet.Split(':')[1];
                string vegOra = item.Veg.Split(':')[0];
                string vegPerc = item.Veg.Split(':')[1];

                osszKezdOra = Convert.ToInt32(kezdOra) * 60 + kezdPerc;
                osszVegOra = Convert.ToInt32(vegOra) * 60 + vegPerc;

                kulonbseg = Convert.ToInt32(osszVegOra) - Convert.ToInt32(osszKezdOra);

                osszOra = kulonbseg / 60;

                textBox14.Text = osszOra.ToString();
            });
        }

        private void SetDefaultStateMunkaido()
        {
            munkaidoGrid.ClearSelection();
            felvesz2.Enabled = true;
            modosit2.Enabled = false;
            torol2.Enabled = false;

            comboBox1.Text = null;
            comboBox3.Text = null;
            textBox2.Text = "";
            textBox11.Text = "";
        }

        private void SetDefaultStateEloleg()
        {
            elolegGrid.ClearSelection();
            felvesz3.Enabled = true;
            modosit3.Enabled = false;
            torol3.Enabled = false;

            comboBox2.Text = null;
            textBox8.Text = "";
            textBox7.Text = "";
        }

        private void SetDefaultStateMunkavallalo()
        {
            munkavallaloGrid.ClearSelection();
            felvesz1.Enabled = true;
            modosit1.Enabled = false;
            torol1.Enabled = false;

            textBox1.Text = "";
            textBox10.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (isChanged)
            {
                SaveToFileMunkaido();
                SaveToFileEloleg();
                SaveToFileMunkavallalo();
            }
        }

        private void felvesz2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || textBox8.Text == "" || textBox2.Text == "" ||
                textBox11.Text == "")
            {
                MessageBox.Show("Nem adtál meg minden adatott");
            }
            else
            {
                isLoaded = false;
                isChanged = true;
                string row = comboBox1.Text + ';' + textBox8.Text + ';' + textBox2.Text + ';' +
                    textBox11.Text;
                munkaido.Add(new TMunkaido(row));
                UpdateGrid();
                MessageBox.Show("Adatok rögzítése");
            }
        }

        private void modosit2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || textBox8.Text == "" || textBox2.Text == "" ||
                textBox11.Text == "")
            {
                MessageBox.Show("Nem adtál meg minden adatott");
            }
            else
            {
                isLoaded = false;
                isChanged = true;
                int index = munkaidoGrid.CurrentRow.Index;
                munkaido[index].Alkalmazott = comboBox1.Text;
                munkaido[index].Datum = textBox8.Text;
                munkaido[index].Kezdet = textBox2.Text;
                munkaido[index].Veg = textBox11.Text;
                UpdateGrid();
                MessageBox.Show("Adatok módosítva");
            }
        }

        private void torol2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Biztosan törlöd az adatot?", "Megerősítés", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                isLoaded = false;
                isChanged = true;
                int index = munkaidoGrid.CurrentRow.Index;
                munkaido.RemoveAt(index);
                UpdateGrid();
                MessageBox.Show("Adat törölve!");
            }
        }

        private void felvesz3_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "" || comboBox3.Text == "" || textBox7.Text == "")
            {
                MessageBox.Show("Nem adtál meg minden adatott");
            }
            else
            {
                isLoaded = false;
                isChanged = true;
                string row = comboBox2.Text + ';' + comboBox3.Text + ';' + textBox7.Text + ';';
                eloleg.Add(new TEloleg(row));
                UpdateGrid();
                MessageBox.Show("Adatok rögzítése");
            }
        }

        private void modosit3_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "" || comboBox3.Text == "" || textBox7.Text == "")
            {
                MessageBox.Show("Nem adtál meg minden adatott");
            }
            else
            {
                isLoaded = false;
                isChanged = true;
                int index = elolegGrid.CurrentRow.Index;
                eloleg[index].Alkalmazott = comboBox2.Text;
                eloleg[index].Datum = comboBox3.Text;
                eloleg[index].Eloleg = Convert.ToInt32(textBox7.Text);
                UpdateGrid();
                MessageBox.Show("Adatok módosítva");
            }
        }

        private void torol3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Biztosan törlöd az adatot?", "Megerősítés", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                isLoaded = false;
                isChanged = true;
                int index = elolegGrid.CurrentRow.Index;
                eloleg.RemoveAt(index);
                UpdateGrid();
                MessageBox.Show("Adat törölve!");
            }
        }

        private void munkaidoGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (isLoaded)
            {
                int index = munkaidoGrid.CurrentRow.Index;
                if (index > -1)
                {
                    comboBox2.Text = munkaidoGrid.Rows[index].Cells[0].Value.ToString();
                    comboBox3.Text = munkaidoGrid.Rows[index].Cells[1].Value.ToString();
                    textBox2.Text = munkaidoGrid.Rows[index].Cells[2].Value.ToString();
                    textBox11.Text = munkaidoGrid.Rows[index].Cells[3].Value.ToString();

                    felvesz2.Enabled = false;
                    modosit2.Enabled = true;
                    torol2.Enabled = true;
                }
            }
        }

        private void elolegGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (isLoaded)
            {
                int index = elolegGrid.CurrentRow.Index;
                if (index > -1)
                {
                    comboBox1.Text = elolegGrid.Rows[index].Cells[0].Value.ToString();
                    textBox8.Text = elolegGrid.Rows[index].Cells[1].Value.ToString();
                    textBox7.Text = elolegGrid.Rows[index].Cells[2].Value.ToString();

                    felvesz3.Enabled = false;
                    modosit3.Enabled = true;
                    torol3.Enabled = true;
                }
            }
        }

        private void munkavallaloGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (isLoaded)
            {
                int index = munkavallaloGrid.CurrentRow.Index;
                if (index > -1)
                {
                    textBox1.Text = munkavallaloGrid.Rows[index].Cells[0].Value.ToString();
                    textBox10.Text = munkavallaloGrid.Rows[index].Cells[1].Value.ToString();
                    textBox3.Text = munkavallaloGrid.Rows[index].Cells[2].Value.ToString();
                    textBox4.Text = munkavallaloGrid.Rows[index].Cells[3].Value.ToString();
                    textBox5.Text = munkavallaloGrid.Rows[index].Cells[4].Value.ToString();
                    textBox6.Text = munkavallaloGrid.Rows[index].Cells[5].Value.ToString();

                    felvesz1.Enabled = false;
                    modosit1.Enabled = true;
                    torol1.Enabled = true;
                }
            }
        }

        private void SaveToFileMunkaido()
        {
            try
            {
                StreamWriter file = new StreamWriter("munkaidok.txt");
                file.WriteLine("alkalmazott,datum,kezdet,veg");
                foreach (var item in munkaido)
                {
                    file.WriteLine("{0};{1};{2};{3}",
                        item.Alkalmazott,
                        item.Datum,
                        item.Kezdet,
                        item.Veg);
                }
                file.Close();
            }
            catch (IOException)
            {
                MessageBox.Show("Hiba");
            }
        }

        private void SaveToFileEloleg()
        {
            try
            {
                StreamWriter file = new StreamWriter("elolegek.txt");
                file.WriteLine("alkalmazott;datum;eloleg");
                foreach (var item in eloleg)
                {
                    file.WriteLine("{0};{1};{2}",
                        item.Alkalmazott,
                        item.Datum,
                        item.Eloleg);
                }
                file.Close();
            }
            catch (IOException)
            {
                MessageBox.Show("Hiba");
            }
        }

        private void SaveToFileMunkavallalo()
        {
            try
            {
                StreamWriter file = new StreamWriter("munkavalallok.txt");
                file.WriteLine("nev; lakcim; beosztas; oraber; telefonszam; email");
                foreach (var item in munkavallalok)
                {
                    file.WriteLine("{0};{1};{2};{3};{4};{5}",
                        item.Nev,
                        item.Lakcim,
                        item.Beosztas,
                        item.Oraber,
                        item.Telefonszam,
                        item.Email);

                }
                file.Close();
                MessageBox.Show("Adatok mentve!");
            }
            catch (IOException)
            {
                MessageBox.Show("Hiba");
            }
        }

        private void munkaidoGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                SetDefaultStateMunkaido();
            }
        }

        private void elolegGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                SetDefaultStateEloleg();
            }
        }

        private void munkavallaloGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                SetDefaultStateMunkavallalo();
            }
        }

        private void felvesz1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
              textBox10.Text == "" ||
              textBox3.Text == "" ||
              textBox4.Text == "" ||
              textBox5.Text == "" ||
              textBox6.Text == "")
            {
                MessageBox.Show("WÓRNING!");
            }
            else
            {
                isLoaded = false;
                isChanged = true;

                string newdata = textBox1.Text + ";" + textBox10.Text + ";" + textBox3.Text + ";" + textBox4.Text + ";" + textBox5.Text + ";" + textBox6.Text;
                munkavallalok.Add(new TMunkavallalo(newdata));
                UpdateGrid();
                MessageBox.Show("Adat felvéve!");
            }
        }

        private void modosit1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
              textBox10.Text == "" ||
              textBox3.Text == "" ||
              textBox4.Text == "" ||
              textBox5.Text == "" ||
              textBox6.Text == "")
            {
                MessageBox.Show("Baj van");
            }
            else
            {
                isLoaded = false;
                isChanged = true;
                int index = munkavallaloGrid.CurrentRow.Index;
                munkavallalok[index].Nev = textBox1.Text;
                munkavallalok[index].Lakcim = textBox10.Text;
                munkavallalok[index].Beosztas = textBox3.Text;
                munkavallalok[index].Oraber = Convert.ToInt32(textBox4.Text);
                munkavallalok[index].Telefonszam = textBox5.Text;
                munkavallalok[index].Email = textBox6.Text;

                UpdateGrid();
                MessageBox.Show("Adat módosítva");
            }
        }

        private void torol1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Mégsem?", "Megerősítés", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                isLoaded = false;
                isChanged = true;
                int index = munkavallaloGrid.CurrentRow.Index;
                munkavallalok.RemoveAt(index);
                UpdateGrid();
                MessageBox.Show("Sikeresen törölve!");
            }
        }

        private void munkavallaloGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            UpdateStatistics();
        }

        private void munkaidoGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            UpdateStatistics();
        }

        private void elolegGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            UpdateStatistics();
        }
    }
}