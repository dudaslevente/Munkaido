﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Munkaido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        public class TMunkavallalo
        {
            public string Nev;
            public string Lakcim;
            public string Beosztas;
            public int Oraber;
            public string Telefonszam;
            public string Email;

            public TMunkavallalo(string row)
            {
                string[] seged = row.Split(';');
                this.Nev = seged[0];
                this.Lakcim = seged[1];
                this.Beosztas = seged[2];
                this.Oraber = Convert.ToInt32(seged[3]);
                this.Telefonszam = seged[4];
                this.Email = seged[5];
            }

        }

        static List<TMunkavallalo> munkavallalok = new List<TMunkavallalo>();
        public static bool isLoaded = false;
        public static bool isChanged = false;
        

        //Munkavállalók kezelése
        private void felvesz1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
              textBox10.Text == "" ||
              textBox3.Text == "" ||
              textBox4.Text == "" ||
              textBox5.Text == "" ||
              textBox6.Text == "")
            {
                MessageBox.Show("WÓRNING!");
            }
            else
            {


                isLoaded = false;
                isChanged = true;


                string newdata = textBox1.Text + ";" + textBox10.Text + ";" + textBox3.Text + ";" + textBox4.Text + ";" + textBox5.Text + ";" + textBox6.Text;

                munkavallalok.Add(new TMunkavallalo(newdata));

                UpdateGrid();
                MessageBox.Show("Adat felvéve!");
                //SetDefaultState();
            }
        }

        private void modosit1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
              textBox10.Text == "" ||
              textBox3.Text == "" ||
              textBox4.Text == "" ||
              textBox5.Text == "" ||
              textBox6.Text == "")
            {
                MessageBox.Show("Baj van");
            }
            else
            {
                isLoaded = false;
                isChanged = true;
                int index = munkavallaloGrid.CurrentRow.Index;
                munkavallalok[index].Nev = textBox1.Text;
                munkavallalok[index].Lakcim = textBox10.Text;
                munkavallalok[index].Beosztas = textBox3.Text;
                munkavallalok[index].Oraber = Convert.ToInt32(textBox4.Text);
                munkavallalok[index].Telefonszam = textBox5.Text;
                munkavallalok[index].Email = textBox6.Text;

                UpdateGrid();
                MessageBox.Show("Adat módosítva");
                //SetDefaultState();
            }
        }

        private void torol1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Mégsem?", "Megerősítés", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                isLoaded = false;
                isChanged = true;
                int index = munkavallaloGrid.CurrentRow.Index;
                munkavallalok.RemoveAt(index);
                UpdateGrid();
                MessageBox.Show("Sikeresen törölve!");
                //SetDefaultState();
            }
        }

        private void UpdateGrid()
        {
            munkavallaloGrid.Rows.Clear();
            munkavallalok.ForEach(item =>
            {
                munkavallaloGrid.Rows.Add();
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[0].Value = item.Nev;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[1].Value = item.Lakcim;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[2].Value = item.Beosztas;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[3].Value = item.Oraber;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[4].Value = item.Telefonszam;
                munkavallaloGrid.Rows[munkavallaloGrid.Rows.Count - 1].Cells[5].Value = item.Email;

            });

            
            SetDefaultStateMunkavallalo();
            //SetDefaultStateEloleg();
            //UpdateStatistics();
            isLoaded = true;
        }

        private void SetDefaultStateMunkavallalo()
        {
            munkavallaloGrid.ClearSelection();
            felvesz1.Enabled = true;
            modosit1.Enabled = false;
            modosit1.Enabled = false;

            textBox1.Text = "";
            textBox10.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
        }

        private void munkavallaloGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (isLoaded)
            {
                int index = munkavallaloGrid.CurrentRow.Index;
                if (index > -1)
                {
                    textBox1.Text = munkavallaloGrid.Rows[index].Cells[0].Value.ToString();
                    textBox10.Text = munkavallaloGrid.Rows[index].Cells[1].Value.ToString();
                    textBox3.Text = munkavallaloGrid.Rows[index].Cells[2].Value.ToString();
                    textBox4.Text = munkavallaloGrid.Rows[index].Cells[3].Value.ToString();
                    textBox5.Text = munkavallaloGrid.Rows[index].Cells[4].Value.ToString();
                    textBox6.Text = munkavallaloGrid.Rows[index].Cells[5].Value.ToString();

                    felvesz1.Enabled = false;
                    modosit1.Enabled = true;
                    torol1.Enabled = true;
                }
            }
        }

        private void LoadFromFileMunkavallalo()
        {
            try
            {
                StreamReader file = new StreamReader("munkavalallok.txt", Encoding.UTF8);
                file.ReadLine();
                while (!file.EndOfStream)
                {
                    munkavallalok.Add(new TMunkavallalo(file.ReadLine()));
                }
                file.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Hiba az adatok beolvasásában!" + ex.Message);
            }
        }

        private void SaveToFileMunkavallalo()
        {
            try
            {
                StreamWriter file = new StreamWriter("munkavalallok.txt");
                file.WriteLine("nev; lakcim; beosztas; oraber; telefonszam; email");
                foreach (var item in munkavallalok)
                {
                    file.WriteLine("{0};{1};{2};{3};{4};{5}",
                        item.Nev,
                        item.Lakcim,
                        item.Beosztas,
                        item.Oraber,
                        item.Telefonszam,
                        item.Email);
                        
                }
                file.Close();
                MessageBox.Show("Adatok mentve!");
            }
            catch (IOException)
            {
                MessageBox.Show("Hiba");
            }
        }

        private void munkavallaloGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                SetDefaultStateMunkavallalo();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveToFileMunkavallalo();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadFromFileMunkavallalo();
        }
    }
    
}
